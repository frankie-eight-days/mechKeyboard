Rev F keyboard schematic review, 21 November 2026.

exports contains the reviewed KiCad XML, configured ERC result and page overview. reviewers contains the original working notes. The release register in design/prelayout-review.md resolves duplicated or superseded interpretations. The working scripts are archived as run. They refer to the original scratch and project paths. The project checker accepts an XML filename. Reproduction commands for the release outputs and powered overvoltage model are in the release register. No board measurements are included.
