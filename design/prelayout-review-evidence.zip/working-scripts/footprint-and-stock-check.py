import csv, re, collections, json, xml.etree.ElementTree as ET, hashlib
from pathlib import Path
d=Path('/tmp/kb-prelayout')
x=ET.parse(d/'net.xml'); refs={c.get('ref'):c for c in x.findall('components/comp')}
local=d/'electronics'; stock=Path('/Applications/KiCad/KiCad.app/Contents/SharedSupport/footprints')
footprints={}; differences=collections.defaultdict(list); fields=collections.Counter()
for ref,c in refs.items():
    fp=c.findtext('footprint'); lib, part=fp.split(':'); p=Path(f'{lib}.pretty') / f'{part}.kicad_mod'
    if fp not in footprints:
        f=next(i/p for i in [local,stock] if (i/p).exists())
        footprints[fp]=set(re.findall(r'\(pad\s+"([^"]+)"\s+(?:thru_hole|smd|connect)',f.read_text()))
    pins={v.get('num') for v in c.findall('units/unit/pins/pin')}; pads=footprints[fp]
    if pins!=pads: differences[(fp,tuple(sorted(pins-pads)),tuple(sorted(pads-pins)))].append(ref)
    fields[c.findtext("fields/field[@name='Assembly']")]+=1
print(len(refs),len(footprints),fields,len(x.findall('nets/net')))
for k,v in differences.items(): print(k, v[:6],len(v))
rows=list(csv.DictReader(Path('design/smt-stock-2026-11-21.csv').open()))
counts=collections.Counter(); rset=set(); mismatch=[]
for row in rows:
    for ref in row['refs'].split():
        counts[row['route']]+=1; rset.add(ref)
        if ref not in refs: print('extra',ref); continue
        c=refs[ref]
        if row['LCSC'] and (row['LCSC']!=c.findtext("fields/field[@name='LCSC']") or row['schematic_mpn']!=c.findtext("fields/field[@name='MPN']")): mismatch.append(ref)
print('stock',counts, 'missing',set(refs)-rset,'extra',rset-set(refs),'mpn/c mismatch',mismatch)
single=[(n.get('name'),n[0].get('ref'),n[0].get('pin')) for n in x.findall('nets/net') if len(n)==1]
print('singles',len(single),[a for a in single if not a[0].startswith('unconnected-')]); print('sheet revs',[(s.findtext('title_block/source'),s.findtext('title_block/rev')) for s in x.findall('design/sheet')])
cfg=json.loads((local/'keyboard.kicad_pro').read_text());print('netclasses',str(cfg.get('net_settings'))[:1900]); print('cfg exclusions', cfg.get('erc',{}).get('erc_exclusions'))
