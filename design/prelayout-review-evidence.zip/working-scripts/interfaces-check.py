import csv, re, xml.etree.ElementTree as E
from pathlib import Path
source=Path('/tmp/kb-prelayout/net.xml')
xml=E.parse(source)
refs={c.get('ref'):c for c in xml.findall('components/comp')}
original={n.get('name'):{(p.get('ref'), p.get('pin')) for p in n.findall('node')} for n in xml.findall('nets/net')}
by_pin={(r,p): name for name, pads in original.items() for r,p in pads}
def same(*want):
    got=original[by_pin[want[0]]]
    assert got==set(want), (want, got)
def require(name, ref, pin):
    assert by_pin[(ref,pin)].split('/')[-1]==name, (name,ref,pin)
rows=[32,31,34,33,35]
cols=[8,7,20,21,22,23,24,51,52,27,28,10,11,38,41]
widths=[15,15,14,14,9]
assert [refs['D'+str(i)].findtext('footprint') for i in range(1,68)]==['Diode_SMD:D_SOD-123']*67
coordinates={x['switch']:x for x in csv.DictReader(Path('mechanical/key-centers.csv').open())}
row_offsets=[sum(widths[:i]) for i in range(len(widths))]
actual_csv={x: (float(c['stem_x_mm']),float(c['stem_y_mm'])) for x,c in coordinates.items()}
assert len(set(actual_csv.values()))==67
for row, (p, width, offset) in enumerate(zip(rows,widths,row_offsets)):
    pads=[('U100',str(p))]
    all_x=[]
    for col in range(width):
        i = offset+col+1
        sw, di='SW'+str(i), 'D'+str(i)
        same((sw,'2'),(di,'2'))
        pads.append((di,'1'))
        assert abs(actual_csv[sw][1]-(row+.5)*19.05)<5e-6, (sw, coordinates[sw], row)
        all_x.append(actual_csv[sw][0])
    assert all_x==sorted(all_x)
    same(*pads)
for col,p in enumerate(cols):
    same(('U100',str(p)),*(('SW'+str(offset+col+1),'1') for width,offset in zip(widths,row_offsets) if col<width))
for ref,p in [('R807','1'),('U201','3'),('J200','A7'),('J200','B7')]:
    require('USB_DM',ref,p)
for ref,p in [('R810','1'),('R817','1'),('U201','5'),('J200','A6'),('J200','B6')]:
    require('USB_DP',ref,p)
same(('U100','67'),('R807','1'),('U201','3'),('J200','A7'),('J200','B7'))
same(('U100','68'),('R810','1'),('R817','1'),('U201','5'),('J200','A6'),('J200','B6'))
for j,u in [(2,44),(4,43),(10,39)]:
    same(('J100',str(j)),('U100',str(u)))
for p in [1,2,3,4,5,16,18,29,30,45,46,47,55]:
    require('GND','U100',str(p))
for p in [17,65]:
    require('3V3','U100',str(p))
nc={'6','15','25','26','49','50','58'}
assert nc=={p for (r,p), name in by_pin.items() if r=='U100' and name.startswith('unconnected-')}
fp=Path('electronics/Keyboard_RF.pretty/BMD-340.kicad_mod').read_text()
fp_pads={int(p) for p in re.findall(r'\(pad "(\d+)" smd rect', fp)}
assert fp_pads==set(range(1,69))
same(('U100','13'),('Y100','1'),('C100','1'))
same(('U100','14'),('Y100','2'),('C101','1'))
for ref,pin in [('U100','13'),('J1000','1'),('J1000','2'),('J1000','3'),('J1000','4')]:
    print(f'{ref}:{pin} {by_pin[(ref,pin)]}')
print(len(refs),len(original),len(by_pin))
print('Exact 67 switch-to-diode links and 20 row/column nets match physical key rows, 68 U100 pads present, VCC/GND/no-connects, USB D+/D− and SWD pin sets passed')
